export const USER_JWT_SECRET =
  process.env.USER_JWT_SECRET || 'Swap-System@123456?';
